#!/usr/bin/env python3
class MiniumError(RuntimeError):
 pass
class MiniumEnvError(MiniumError):
 pass
class MiniumProtocolError(MiniumError):
 pass
# Created by pyminifier (https://github.com/liftoff/pyminifier)
